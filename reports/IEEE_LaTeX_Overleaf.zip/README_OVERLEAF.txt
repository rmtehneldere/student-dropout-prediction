IEEE LaTeX Raporu - Overleaf Derleme
=====================================
1. overleaf.com -> New Project -> Upload Project -> bu ZIP'i yukle
2. Menu -> Compiler = pdfLaTeX
3. Recompile -> 7 sayfalik IEEE PDF -> Download PDF
Not: IEEEtran class Overleaf'te hazir gelir; ekstra dosya gerekmez.
